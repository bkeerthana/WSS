<?php
require_once __DIR__ . '/db.php';
ensure_session();
$_SESSION = [];
session_destroy();
header('Location: login.php');
exit;

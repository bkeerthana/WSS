<?php
require_once __DIR__ . '/config.php';

function db(): PDO {
  $dbPath = __DIR__ . '/data/app.db';
  $dsn = 'sqlite:' . $dbPath;

  $pdo = new PDO($dsn);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
  return $pdo;
}

function ensure_session(): void {
  if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
  }
}

function require_login(): void {
  ensure_session();
  if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
  }
}

function h(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

<?php
require_once __DIR__ . '/db.php';

$db = db();

// Create tables
$db->exec("CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user'
)");

$db->exec("CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
)");

$db->exec("CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  secret_note TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
)");

// Seed demo users if missing
$existing = $db->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'] ?? 0;

if ((int)$existing === 0) {
  $stmt = $db->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");

  // Intentionally weak demo passwords for class
  $stmt->execute(['alice', 'alice123', 'user']);
  $stmt->execute(['bob', 'bob123', 'user']);
  $stmt->execute(['admin', 'admin123', 'admin']);

  // Seed notes
  $userIds = $db->query("SELECT id, username FROM users")->fetchAll();
  $noteStmt = $db->prepare("INSERT INTO notes (user_id, secret_note) VALUES (?, ?)");

  foreach ($userIds as $u) {
    $noteStmt->execute([$u['id'], "Private note for {$u['username']} (demo data)"]);
  }
}

echo "<h2>Database initialized.</h2>";
echo "<p><a href='login.php'>Go to Login</a> | <a href='reset_db.php'>Reset DB</a></p>";

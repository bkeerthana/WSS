<?php
require_once __DIR__ . '/db.php';
ensure_session();

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
  header('Location: login.php?err=' . urlencode('Missing credentials'));
  exit;
}

$db = db();

try {
  if (VULN_SQLI) {
    // VULNERABLE: SQL Injection possible via string concatenation
    // Exploit technique: SQLi
    // Example payload:  ' OR '1'='1
    $sql = "SELECT id, username, role FROM users WHERE username = '$username' AND password = '$password' LIMIT 1";
    $user = $db->query($sql)->fetch();
  } else {
    // SAFE: Prepared statement blocks SQLi payloads
    $stmt = $db->prepare("SELECT id, username, role FROM users WHERE username = ? AND password = ? LIMIT 1");
    $stmt->execute([$username, $password]);
    $user = $stmt->fetch();
  }

  if (!$user) {
    header('Location: login.php?err=' . urlencode('Invalid credentials'));
    exit;
  }

  $_SESSION['user'] = $user;
  header('Location: dashboard.php');
  exit;

} catch (Throwable $e) {
  // For teaching, show minimal error (avoid leaking SQL details)
  header('Location: login.php?err=' . urlencode('Login error (check config/init_db).'));
  exit;
}

# Web Security Mini-Lab (SQLi + XSS + IDOR) — Classroom Demo (Localhost Only)

This is an intentionally vulnerable **toy** web application designed for **teaching** basic terms:
vulnerability, threat, exploit, payload, attack, impact, and risk — using SQL Injection, XSS, and IDOR.

## Safety notes (important)
- Run **only on your local machine** (localhost) in an isolated lab environment.
- Do not expose this app to the internet or a shared network.
- Use demo accounts and dummy data only.

## Requirements
- PHP 8+ (XAMPP/WAMP/MAMP is fine)
- No external database required (uses SQLite via PDO)



## Quick start ( XAMPP)
1. Copy the folder `bas_lab` into `xampp/htdocs/`
2. Start Apache
3. Open:
   http://localhost/bas_lab/init_db.php
4. Then:
   http://localhost/bas_lab/login.php

## Demo accounts
- alice / alice123 (role: user)
- bob / bob123 (role: user)
- admin / admin123 (role: admin)

## Demo toggles (vulnerable vs safe)
Open `config.php` and set:
- VULN_SQLI  (SQL Injection on login)
- VULN_XSS   (Stored XSS in comments)
- VULN_IDOR  (IDOR in account view)

 flow:
1. Start with all VULN_* = true
2. Demonstrate each vulnerability and its exploit/payload
3. Switch VULN_* to false and re-run the same payloads to show mitigation

## demo 
- Asset: accounts, comments, notes
- Vulnerability: insecure query / unescaped output / missing authorization
- Threat: unauthorized access / data theft / session hijack
- Exploit: SQLi / XSS / IDOR technique
- Payload: strings like `' OR '1'='1` or `<script>...</script>` or `?id=2`
- Attack: submitting payload via browser
- Impact: login bypass / script execution / viewing another user's data
- Risk: Likelihood × Impact (high if easy + severe)

## Reset database
Visit:
- http://localhost:8000/reset_db.php

## Files overview
- config.php        : vulnerability toggles
- db.php            : SQLite connection helper
- init_db.php       : creates DB + inserts demo data
- reset_db.php      : resets DB
- login.php         : login form
- auth.php          : SQLi demo in vulnerable mode; prepared statements in safe mode
- dashboard.php     : links to demos
- comments.php      : stored XSS demo (vulnerable vs safe)
- account.php       : IDOR demo (vulnerable vs safe)
- logout.php        : clears session

<?php
require_once __DIR__ . '/db.php';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title><?= h(APP_NAME) ?> - Demo Terms Map</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 28px; }
    .box { border: 1px solid #333; border-radius: 10px; padding: 18px; max-width: 900px; }
    code { background: #f2f2f2; padding: 2px 6px; border-radius: 6px; }
  </style>
</head>
<body>
  <div class="box">
    <h2>Classroom Terms Map</h2>
    <p><b>Asset</b>: accounts, comments, notes (anything valuable).</p>
    <p><b>Vulnerability</b>: weak login query / unescaped output / missing authorization.</p>
    <p><b>Threat</b>: account takeover, data exposure, script injection.</p>
    <p><b>Exploit</b>: SQLi / XSS / IDOR technique (method).</p>
    <p><b>Payload</b>: the actual input string/parameter (e.g., SQLi string, script tag, id value).</p>
    <p><b>Attack</b>: submitting the payload to trigger the exploit.</p>
    <p><b>Impact</b>: unauthorized access, script execution, data leakage.</p>
    <p><b>Risk</b>: likelihood × impact (prioritize what to fix first).</p>

    <p style="margin-top:14px;">
      <a href="login.php">Login</a> | <a href="dashboard.php">Dashboard</a>
    </p>
  </div>
</body>
</html>

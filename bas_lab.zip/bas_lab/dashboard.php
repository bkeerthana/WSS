<?php
require_once __DIR__ . '/db.php';
require_login();
$user = $_SESSION['user'];
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title><?= h(APP_NAME) ?> - Dashboard</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 28px; }
    .box { border: 1px solid #333; border-radius: 10px; padding: 18px; max-width: 760px; }
    a { display: inline-block; margin: 8px 0; }
    code { background: #f2f2f2; padding: 2px 6px; border-radius: 6px; }
    .muted { color: #666; }
    ul { margin-top: 6px; }
  </style>
</head>
<body>
  <div class="box">
    <h2>Welcome, <?= h($user['username']) ?> (role: <?= h($user['role']) ?>)</h2>
    <p class="muted">
      Use this page to demonstrate vulnerability → exploit → payload → attack → impact → risk.
      Toggle modes in <code>config.php</code>.
    </p>

    <h3>Demos</h3>
    <ul>
      <li><a href="comments.php">Stored XSS Demo (Comments)</a></li>
      <li><a href="account.php?id=1">IDOR Demo (Account View) — try changing <code>?id=</code></a></li>
    </ul>

    <h3>Current configuration</h3>
    <ul>
      <li>VULN_SQLI: <code><?= VULN_SQLI ? 'true' : 'false' ?></code></li>
      <li>VULN_XSS: <code><?= VULN_XSS ? 'true' : 'false' ?></code></li>
      <li>VULN_IDOR: <code><?= VULN_IDOR ? 'true' : 'false' ?></code></li>
    </ul>

    <p><a href="logout.php">Logout</a></p>
  </div>
</body>
</html>

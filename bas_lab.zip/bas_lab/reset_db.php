<?php
require_once __DIR__ . '/db.php';

$dbPath = __DIR__ . '/data/app.db';
if (file_exists($dbPath)) {
  unlink($dbPath);
}

echo "<h2>Database deleted.</h2>";
echo "<p>Now re-initialize: <a href='init_db.php'>init_db.php</a></p>";

<?php
require_once __DIR__ . '/db.php';
require_login();
$db = db();
$user = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $body = $_POST['body'] ?? '';
  $body = trim($body);

  if ($body !== '') {
    $stmt = $db->prepare("INSERT INTO comments (user_id, body, created_at) VALUES (?, ?, ?)");
    $stmt->execute([$user['id'], $body, date('c')]);
  }
  header('Location: comments.php');
  exit;
}

$rows = $db->query("SELECT c.id, c.body, c.created_at, u.username
                    FROM comments c JOIN users u ON u.id=c.user_id
                    ORDER BY c.id DESC LIMIT 20")->fetchAll();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title><?= h(APP_NAME) ?> - Comments (XSS)</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 28px; }
    .box { border: 1px solid #333; border-radius: 10px; padding: 18px; max-width: 860px; }
    textarea { width: 100%; height: 90px; padding: 10px; }
    button { margin-top: 10px; padding: 10px 14px; }
    .comment { border-top: 1px solid #ddd; padding: 10px 0; }
    .meta { color: #666; font-size: 0.9em; margin-bottom: 6px; }
    code { background: #f2f2f2; padding: 2px 6px; border-radius: 6px; }
  </style>
</head>
<body>
  <div class="box">
    <h2>Stored XSS Demo — Comments</h2>
    <p>
      Logged in as <b><?= h($user['username']) ?></b>.
      Vulnerable mode: <code><?= VULN_XSS ? 'true' : 'false' ?></code>
    </p>

    <p>
      Tip (ONLY for teaching): if <code>VULN_XSS=true</code>, post a payload like:
      <code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code>
    </p>

    <form method="post">
      <label>Add a comment</label><br/>
      <textarea name="body" placeholder="Write a comment..."></textarea>
      <button type="submit">Post</button>
    </form>

    <h3>Recent comments</h3>

    <?php foreach ($rows as $r): ?>
      <div class="comment">
        <div class="meta">
          #<?= (int)$r['id'] ?> by <?= h($r['username']) ?> at <?= h($r['created_at']) ?>
        </div>

        <div>
          <?php if (VULN_XSS): ?>
            <!-- VULNERABLE: unescaped rendering => stored XSS executes in victim's browser -->
            <?= $r['body'] ?>
          <?php else: ?>
            <!-- SAFE: escape output => payload renders as text -->
            <?= h($r['body']) ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>

    <p style="margin-top:14px;">
      <a href="dashboard.php">Back to Dashboard</a> | <a href="reset_db.php">Reset DB</a>
    </p>
  </div>
</body>
</html>

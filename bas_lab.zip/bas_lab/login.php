<?php
require_once __DIR__ . '/db.php';
ensure_session();
$err = $_GET['err'] ?? '';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title><?= h(APP_NAME) ?> - Login</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 28px; }
    .card { max-width: 520px; padding: 18px; border: 1px solid #333; border-radius: 10px; }
    label { display: block; margin-top: 10px; }
    input { width: 100%; padding: 10px; margin-top: 6px; }
    button { margin-top: 14px; padding: 10px 14px; }
    .muted { color: #666; font-size: 0.95em; }
    .err { color: #b00020; margin-top: 10px; }
    code { background: #f2f2f2; padding: 2px 6px; border-radius: 6px; }
  </style>
</head>
<body>
  <div class="card">
    <h2><?= h(APP_NAME) ?> — Login</h2>
    <p class="muted">
      Demo accounts: <code>alice/alice123</code>, <code>bob/bob123</code>, <code>admin/admin123</code><br/>
      Toggle vulnerabilities in <code>config.php</code>.
    </p>

    <?php if ($err): ?>
      <div class="err"><?= h($err) ?></div>
    <?php endif; ?>

    <form method="post" action="auth.php">
      <label>Username</label>
      <input name="username" autocomplete="username" required />

      <label>Password</label>
      <input name="password" type="password" autocomplete="current-password" required />

      <button type="submit">Sign in</button>
    </form>

    <p class="muted">
      Tip for SQLi demo (ONLY when <code>VULN_SQLI=true</code>): try password as <code>' OR '1'='1</code>
      with any listed username.
    </p>
  </div>
</body>
</html>

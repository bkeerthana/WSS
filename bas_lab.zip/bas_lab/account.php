<?php
require_once __DIR__ . '/db.php';
require_login();

$db = db();
$me = $_SESSION['user'];

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
  $id = (int)$me['id'];
}

// In SAFE mode, enforce authorization (no IDOR):
// - regular users can only view their own account
// - admin can view any account
if (!VULN_IDOR) {
  if ($me['role'] !== 'admin' && $id !== (int)$me['id']) {
    http_response_code(403);
    echo "<h2>403 Forbidden</h2>";
    echo "<p>Access denied (authorization check prevented IDOR).</p>";
    echo "<p><a href='dashboard.php'>Back to Dashboard</a></p>";
    exit;
  }
}

// VULNERABLE mode: no authorization check => any logged-in user can view any id (IDOR)
$stmt = $db->prepare("SELECT id, username, role FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$target = $stmt->fetch();

if (!$target) {
  echo "<h2>User not found</h2>";
  echo "<p><a href='dashboard.php'>Back to Dashboard</a></p>";
  exit;
}

$noteStmt = $db->prepare("SELECT secret_note FROM notes WHERE user_id = ? LIMIT 1");
$noteStmt->execute([$target['id']]);
$note = $noteStmt->fetch()['secret_note'] ?? '(no note)';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title><?= h(APP_NAME) ?> - Account (IDOR)</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 28px; }
    .box { border: 1px solid #333; border-radius: 10px; padding: 18px; max-width: 760px; }
    code { background: #f2f2f2; padding: 2px 6px; border-radius: 6px; }
    .muted { color: #666; }
  </style>
</head>
<body>
  <div class="box">
    <h2>IDOR Demo — Account View</h2>
    <p class="muted">Vulnerable mode: <code><?= VULN_IDOR ? 'true' : 'false' ?></code></p>

    <p>
      You are logged in as <b><?= h($me['username']) ?></b> (role: <?= h($me['role']) ?>).
    </p>

    <h3>Viewing account for id = <?= (int)$target['id'] ?></h3>
    <ul>
      <li>Username: <b><?= h($target['username']) ?></b></li>
      <li>Role: <b><?= h($target['role']) ?></b></li>
      <li>Private note (asset): <b><?= h($note) ?></b></li>
    </ul>

    <p>
      Teaching tip: change the URL parameter <code>?id=</code> (e.g., 1, 2, 3) and observe whether authorization is enforced.
    </p>

    <p style="margin-top:14px;">
      <a href="dashboard.php">Back to Dashboard</a> | <a href="logout.php">Logout</a>
    </p>
  </div>
</body>
</html>

<?php
// Toggle vulnerabilities for teaching demos.
// IMPORTANT: Run only on localhost in a lab environment.

define('VULN_SQLI', true);   // true => insecure string concatenation query in auth.php
define('VULN_XSS',  true);   // true => unescaped stored XSS rendering in comments.php
define('VULN_IDOR', true);   // true => missing authorization in account.php

// Basic app settings
define('APP_NAME', 'WebSec Mini-Lab');
define('SESSION_NAME', 'WEBSEC_DEMO_SESS');

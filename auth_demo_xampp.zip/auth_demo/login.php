<?php
require __DIR__ . '/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  $stmt = $mysqli->prepare("SELECT id, email, pass_hash FROM users WHERE email = ? LIMIT 1");
  if (!$stmt) {
    $error = "Prepare failed: " . e($mysqli->error);
  } else {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    if ($user && password_verify($password, $user['pass_hash'])) {
      session_regenerate_id(true);

      $_SESSION['user_id'] = (int)$user['id'];
      $_SESSION['email'] = $user['email'];

      // Optional: upgrade hash if algorithm/cost changes
      if (password_needs_rehash($user['pass_hash'], PASSWORD_DEFAULT)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $up = $mysqli->prepare("UPDATE users SET pass_hash=? WHERE id=?");
        if ($up) {
          $up->bind_param("si", $newHash, $_SESSION['user_id']);
          $up->execute();
          $up->close();
        }
      }

      header("Location: dashboard.php");
      exit;
    } else {
      $error = "Invalid credentials.";
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login</title>
</head>
<body>
  <h2>Login</h2>

  <p><a href="install.php">Installer</a> | <a href="register.php">Register</a></p>

  <?php if ($error): ?>
    <p style="color:red;"><?php echo e($error); ?></p>
  <?php endif; ?>

  <form method="post" autocomplete="off">
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>

    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
  </form>
</body>
</html>

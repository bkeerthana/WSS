<?php
// install.php - one-click DB/table setup
declare(strict_types=1);

$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'auth_demo';

$status = '';
$error = '';

function e(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS);
  if ($mysqli->connect_error) {
    $error = "DB connection failed: " . $mysqli->connect_error;
  } else {
    $mysqli->set_charset('utf8mb4');

    // 1) Create database
    $sqlDb = "CREATE DATABASE IF NOT EXISTS `$DB_NAME` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if (!$mysqli->query($sqlDb)) {
      $error = "Failed to create database: " . $mysqli->error;
    } else {
      if (!$mysqli->select_db($DB_NAME)) {
        $error = "Failed to select database: " . $mysqli->error;
      } else {
        // 2) Create users table
        $sqlTable = "
          CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(190) NOT NULL UNIQUE,
            pass_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$mysqli->query($sqlTable)) {
          $error = "Failed to create table: " . $mysqli->error;
        } else {
          $status = "✅ Installation completed: database <b>" . e($DB_NAME) . "</b> and table <b>users</b> are ready.";
        }
      }
    }
    $mysqli->close();
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>auth_demo Installer</title>
</head>
<body>
  <h2>auth_demo Installer (PHP + MySQL)</h2>

  <p>This will create the database <b><?php echo e($DB_NAME); ?></b> and the table <b>users</b>.</p>

  <?php if ($error): ?>
    <p style="color:red;"><?php echo e($error); ?></p>
  <?php endif; ?>

  <?php if ($status): ?>
    <p style="color:green;"><?php echo $status; ?></p>
    <p>
      Next:
      <a href="register.php">Register</a> |
      <a href="login.php">Login</a>
    </p>
  <?php endif; ?>

  <form method="post">
    <button type="submit">Install Database + Table</button>
  </form>

  <hr>
  <p><b>Note:</b> If your MySQL root has a password, edit <code>install.php</code> and <code>config.php</code>.</p>
</body>
</html>

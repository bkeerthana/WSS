<?php
require __DIR__ . '/config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = "Invalid email format.";
  } elseif (strlen($password) < 8) {
    $error = "Password must be at least 8 characters.";
  } else {
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $mysqli->prepare("INSERT INTO users (email, pass_hash) VALUES (?, ?)");
    if (!$stmt) {
      $error = "Prepare failed: " . e($mysqli->error);
    } else {
      $stmt->bind_param("ss", $email, $hash);

      if ($stmt->execute()) {
        $success = "Registered successfully. You can now login.";
      } else {
        if ($mysqli->errno === 1062) {
          $error = "Email already exists.";
        } else {
          $error = "Insert failed: " . e($mysqli->error);
        }
      }
      $stmt->close();
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Register</title>
</head>
<body>
  <h2>Register</h2>

  <p><a href="install.php">Installer</a> | <a href="login.php">Login</a></p>

  <?php if ($error): ?>
    <p style="color:red;"><?php echo e($error); ?></p>
  <?php endif; ?>

  <?php if ($success): ?>
    <p style="color:green;"><?php echo e($success); ?></p>
  <?php endif; ?>

  <form method="post" autocomplete="off">
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>

    <label>Password (min 8 chars):</label><br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Create account</button>
  </form>
</body>
</html>

<?php
require __DIR__ . '/config.php';

if (empty($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Dashboard</title>
</head>
<body>
  <h2>Dashboard</h2>
  <p>Welcome, <?php echo e($_SESSION['email']); ?>!</p>

  <p>This page is protected by a session check.</p>

  <p><a href="logout.php">Logout</a></p>
</body>
</html>

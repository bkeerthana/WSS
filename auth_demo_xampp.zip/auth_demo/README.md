# auth_demo (PHP + MySQL / XAMPP)

## What this contains
A minimal authentication demo focusing on **secure password storage**:
- Register: stores `password_hash()` in MySQL
- Login: verifies via `password_verify()`
- Protected page: session check
- Logout: destroys session
- **Installer**: `install.php` creates the database and table when you click a button

## Setup (XAMPP on Windows)
1. Start **Apache** and **MySQL** in XAMPP Control Panel
2. Copy the extracted folder `auth_demo/` to:
   `C:\xampp\htdocs\auth_demo\`
3. Open in browser:
   - Install DB/table: `http://localhost/auth_demo/install.php`
   - Register: `http://localhost/auth_demo/register.php`
   - Login: `http://localhost/auth_demo/login.php`

## Default DB settings
- Host: 127.0.0.1
- User: root
- Password: (empty)
- Database: auth_demo

You can change these in `config.php` if your setup differs.

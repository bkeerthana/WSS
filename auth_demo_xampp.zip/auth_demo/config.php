<?php
// config.php
declare(strict_types=1);

// -----------------------------
// Session hardening
// -----------------------------
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');

// If using HTTPS, set to 1. In XAMPP local HTTP, keep 0.
ini_set('session.cookie_secure', '0');

// Helps mitigate CSRF for normal form posts.
ini_set('session.cookie_samesite', 'Lax');

session_start();

// -----------------------------
// Database configuration
// -----------------------------
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';           // default in XAMPP
$DB_NAME = 'auth_demo';

// Connect (mysqli)
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS);
if ($mysqli->connect_error) {
  http_response_code(500);
  exit("DB connection failed: " . htmlspecialchars($mysqli->connect_error));
}
$mysqli->set_charset('utf8mb4');

// Select DB if it exists; install.php will create it if not.
$mysqli->query("CREATE DATABASE IF NOT EXISTS `$DB_NAME` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$mysqli->select_db($DB_NAME);

// Escape output helper
function e(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}
